/**
 * rutesCategoria.js
 * Definició de les rutes relacionades amb les categories
 */

const express = require('express');
const router = express.Router();
const llistaReproduccioController = require('../controllers/LlistaReproduccioController');



router.get('/', llistaReproduccioController.obtenirTotes);


/**
 * @swagger
 * /api/videos/{id}:
 *   get:
 *     summary: Obté un vídeo per ID
 *     description: Retorna la informació detallada d'un vídeo específic
 *     tags: [Vídeos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del vídeo
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Vídeo obtingut amb èxit
 *       404:
 *         description: Vídeo no trobat
 *       500:
 *         description: Error intern del servidor
 */
// router.get('/:id', videoController.obtenirPerId);


module.exports = router;